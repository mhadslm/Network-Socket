/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netsockets;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 *
 * @author A6UAHMED
 */
public class Server {

   
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        startServer();
        System.out.println("the Server is waiting for clients to connect...");

    }

    private static void startServer() {
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        Runnable serverTask = new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket serverSocket = new ServerSocket(9999);
                    while (true) {
                        Socket clientSocket = serverSocket.accept();
                        new MultiThreadServer().processClient(clientSocket);
                    }
                } catch (IOException e) {
                    System.err.println("Unable to process client request");
                    //e.printStackTrace();
                }
            }
        };
        Thread newtask = new Thread(serverTask);
        newtask.start();
        // send to background
        //Thread serverThread = new Thread(serverTask);
        // delay to first execution 
        //long initialDelay = 0;
        //TimeUnit unit = TimeUnit.MILLISECONDS;
        // period between successive executions
        //long period = 1;// one millisecond
        //scheduler.scheduleAtFixedRate(serverThread, initialDelay, period, unit);

    }

   
}
