/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netsockets;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import javax.swing.JFileChooser;

/**
 *
 * @author A6UAHMED
 */
public class MultiThreadServer {
    private  DataInputStream socketIn;
    private  DataOutputStream socketOut;
    private  DataInputStream fileIn;
    private  DataOutputStream fileOut;
    //private  JFileChooser fileChooser;
    
    private  File serverUploadingDirectory;
    private  File uploadedFile;
    private  String uploadedFileName;
    
    private  String fileSeparator;
    
    private  File serverDownloadingDirectory;
    private  File file2download;
    private  String file2downloadName;
    
    private  byte[] buffer;

    

    public  void processClient(Socket socket) {
        
        //fileChooser = new JFileChooser(new File("."));
        fileSeparator = System.getProperty("file.separator");
        //fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //fileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
        //fileChooser.setDialogTitle("Select downloads directory");
        serverUploadingDirectory = new File(System.getProperty("user.dir") + fileSeparator + "server" + fileSeparator + "uploads");
        serverDownloadingDirectory = new File(System.getProperty("user.dir") + fileSeparator + "server" + fileSeparator + "downloads");
                buffer = new byte[128];

        try {

            socketIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            socketOut = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            System.out.println("connection with the client is OK");
            buffer = new byte[128];
            //download or upload
            socketIn.read(buffer);
            if (new String(buffer, "UTF-8").trim().equals("download")) {//downloads
                //download
                System.out.println("processing download request ...");
                //accepting upload request
                socketOut.write("OK".getBytes("UTF-8"));// sending OK to client and wait for file bytes
                socketOut.flush();
                buffer = new byte[128];
                socketIn.read(buffer);//read the file name
                file2downloadName = new String(buffer, "UTF-8").trim();
                boolean found = false;
                for (int i = 0; i < serverDownloadingDirectory.listFiles().length; i++) {
                    if (serverDownloadingDirectory.list()[i].equals(file2downloadName)) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    System.out.println(" file named " + file2downloadName + " was found");
                    file2download = new File(serverDownloadingDirectory + fileSeparator + file2downloadName);
                    //start downloading the file
                    fileIn = new DataInputStream(new BufferedInputStream(new FileInputStream(file2download)));
                    while ((fileIn.read(buffer)) > 0) {
                        socketOut.write(buffer);
                    }
                    socketOut.flush();
                    socketOut.close();
                    socketIn.close();
                    fileIn.close();

                    System.out.println("the selected file " + file2download + " was send to client successfully");
                } else {
                    System.out.println(" file named " + file2downloadName + " was not found");
                }
                socket.close();
            } else if (new String(buffer, "UTF-8").trim().equals("upload")) {//uploads
                System.out.println("processing upload request ...");
                //accepting upload request
                socketOut.write("OK".getBytes("UTF-8"));// sending OK to client and wait for file bytes
                socketOut.flush();
                socketIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                buffer = new byte[128];
                socketIn.read(buffer);
                uploadedFileName = new String(buffer, "UTF-8").trim().split(":")[0];
                //System.out.println(uploadedFileName);
                uploadedFile = new File(serverUploadingDirectory + fileSeparator + uploadedFileName);
                uploadedFile.createNewFile();
                fileOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(uploadedFile)));
                fileOut.write(new String(buffer, "UTF-8").trim().split(":")[1].getBytes());
                while ((socketIn.read(buffer)) > 0) {
                    fileOut.write(buffer);

                }
                System.out.println("the selected file " + uploadedFileName + " was uploaded to the server successfully to path: " + uploadedFile.getPath());
                socketIn.close();
                socketOut.close();
                //fileIn.close();
                fileOut.close();
                socket.close();
            } else {
                System.out.println("Unknown option");
            }

        } catch (SocketException se) {
            se.printStackTrace();

        } catch (IOException ioe) {
            ioe.printStackTrace();

        }

    }
}
