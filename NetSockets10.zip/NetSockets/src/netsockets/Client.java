/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package netsockets;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author A6UAHMED
 */
public class Client {

    private static Socket socket = null;
    private static DataInputStream socketIn;
    private static DataOutputStream socketOut;
    private static DataInputStream fileIn;
    private static DataOutputStream fileOut;

    private static byte[] buffer;
    //private static JFileChooser fileChooser;
    private static File clientUploadDirectory;
    private static File serverDownloadingDirectory;
    private static File clientDownloadedDirectory;
    private static File file2upload;
    private static File file2download;
    private static String file2downloadName;
    private static String file2uploadName;
    private static String fileSeparator;
    private static Scanner scanner = new Scanner(System.in);
    private static final String menue = "d: download\nu: upload\nm: menu\nq: exit";
    private static String userInput;
    private static BufferedReader reader;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        System.out.println(menue);
        System.out.println("Enter your choise:");
        userInput = "";
        reader = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
        buffer = new byte[128];
        fileSeparator = System.getProperty("file.separator");
        userInput = reader.readLine();
        switch (userInput) {
            case "d":
                download();
                break;
            case "u":
                upload();
                break;
            case "m":
                System.out.println(menue);
                break;
            case "q":
                System.exit(1);
            default:
                System.out.println("Usage: \n" + menue);
        }
    }

    private static void download() throws IOException {
        try {
            socket = new Socket("127.0.0.1", 9999);
            socketOut = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            socketIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            System.out.println("connection with the server is OK");
            serverDownloadingDirectory = new File(System.getProperty("user.dir") + fileSeparator + "server" + fileSeparator + "downloads");
            clientDownloadedDirectory = new File(System.getProperty("user.dir") + fileSeparator + "client" + fileSeparator + "downloads");

            System.out.println("download request was accepted by server over socket ...");
            // read file name to server 
            System.out.println("select file from " + serverDownloadingDirectory + " for downloading from the server:");
            file2downloadName = scanner.nextLine().trim();
            socketOut.write("download".getBytes("UTF-8"));
            socketOut.flush();
            System.out.println("download request was sent to server over socket ...");

            // read server OK message
            buffer = new byte[128];
            socketIn.read(buffer);
            if (new String(buffer, "UTF-8").trim().equals("OK")) {
                //send file name
                socketOut.write(file2downloadName.getBytes("UTF-8"));
                socketOut.flush();
            }
            long sTime = System.nanoTime();
            System.out.println("start time: " + sTime);
            // read file bytes
            buffer = new byte[128];
            if ((socketIn.read(buffer)) > 0) {
                file2download = new File(clientDownloadedDirectory + fileSeparator + file2downloadName);
                file2download.createNewFile();
                fileOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file2download)));
                while ((socketIn.read(buffer)) > 0) {
                    fileOut.write(buffer);
                }
                System.out.println("the selected file " + file2downloadName + " was downloaded successfully from the server to path: " + file2download.getPath());
            } else {
                System.out.println("file was not found on the server");
            }
            fileOut.flush();
            socketIn.close();
            socketOut.close();

            long eTime = System.nanoTime();
            System.out.println("end time: " + eTime);
            System.out.println("elapsed time: " + (eTime - sTime) / 1000 + " mill seconds");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void upload() {
        try {
            socket = new Socket("127.0.0.1", 9999);
            fileSeparator = System.getProperty("file.separator");
            clientUploadDirectory = new File(System.getProperty("user.dir") + fileSeparator + "client" + fileSeparator + "uploads");
            //fileChooser = new JFileChooser();
            //fileChooser.setAcceptAllFileFilterUsed(false);
            //fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Text files", "txt"));
            //fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            //fileChooser.setDialogTitle("select a text file (*.txt) to uplad to the server");
            //fileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
            //fileChooser.setCurrentDirectory(selectedFile);
            //fileChooser.showOpenDialog(null);
            //selectedFile = fileChooser.getSelectedFile();

            System.out.println("connection with the server is OK");
            socketOut = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            socketOut.write("upload".getBytes("UTF-8"));
            socketOut.flush();
            System.out.println("upload request was sent to server over socket ...");
            // read server OK message
            socketIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            buffer = new byte[128];
            socketIn.read(buffer);
            if (new String(buffer, "UTF-8").trim().equals("OK")) {//downloads
                System.out.println("upload request was accepted by server over socket ...");
                // read file name to server 
                System.out.println("select file from " + clientUploadDirectory + " for uploading to the server:");
                file2uploadName = scanner.nextLine().trim();
                file2upload = new File(clientUploadDirectory + fileSeparator + file2uploadName);
                if (file2upload.isFile()) {
                    // start uploading 
                    fileIn = new DataInputStream(new BufferedInputStream(new FileInputStream(file2upload)));
                    socketOut = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
                    socketOut.write(file2upload.getName().getBytes("UTF-8"));
                    socketOut.write(":".getBytes("UTF-8"));// file name separator
                    while ((fileIn.read(buffer)) > 0) {
                        socketOut.write(buffer);
                    }
                    System.out.println("the selected file " + clientUploadDirectory.getName() + " was uploaded to the server successfully");
                } else {
                    System.out.println("file was not found");
                    return;
                }
            } else {
                System.out.println("upload request was rejected by server over socket ...");
            }
            socketOut.close();
            socketIn.close();
            fileIn.close();
            socket.close();

        } catch (Exception e) {
        }
    }

}
